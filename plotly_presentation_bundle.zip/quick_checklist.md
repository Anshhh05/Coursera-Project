# Quick Checklist (Submission-Ready)

**Last updated:** 2025-10-30

1) Open `presentation.Rmd` in RStudio.  
2) Click **Knit** → confirm `presentation.html` opens as a slide deck.  
3) Check title slide shows today's date.  
4) Confirm both Plotly plots are interactive (you can pan/zoom/hover).  
5) Publish to **RPubs** or **GitHub Pages** or **NeoCities** (choose one).  
6) Copy the live link for submission.

**Manual actions you MUST do** are highlighted with ">>> YOU DO THIS <<<" in the main guide.
