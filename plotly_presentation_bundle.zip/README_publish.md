# How to Publish Your R Markdown Presentation

This project contains a single R Markdown file: `presentation.Rmd`. It renders to an **ioslides HTML presentation** with an **interactive Plotly plot** and today's **date** on the title slide (generated dynamically with `Sys.Date()`).

## Prerequisites
In R (or RStudio), install:
```r
install.packages(c("rmarkdown", "plotly", "dplyr", "tibble"))
```

## Render the presentation
Open `presentation.Rmd` in RStudio and click **Knit**, or run:
```r
rmarkdown::render("presentation.Rmd")
```
This will create `presentation.html` in the same folder.

## Publish Options

### Option A: RPubs (quickest)
1. In RStudio, open `presentation.html` in the Viewer.
2. Click **Publish** > **RPubs** and follow the prompts.
3. Ensure the published page shows the **date** and that the Plotly plot is **interactive**.
4. Submit the RPubs link.

### Option B: GitHub Pages
1. Create a new GitHub repository and add `presentation.html` (you can name it `index.html` to make it the default).
2. Commit and push.
3. In repo **Settings** > **Pages**, set **Source** to "Deploy from a branch" (e.g., `main`), and select the branch & folder.
4. Copy the live site URL (usually `https://<username>.github.io/<repo>/`).

### Option C: NeoCities
1. Create a free NeoCities account.
2. Upload `presentation.html` (or `index.html`) via the NeoCities dashboard.
3. Copy your live site URL.

## Rubric Checklist
- **Date present and recent**: The YAML `date` field is computed at knit time, ensuring it's within two months as long as you knit close to submission.
- **Presentation + Plotly**: `ioslides_presentation` with embedded interactive Plotly widgets.

## Troubleshooting
- If the plot is not interactive, make sure you knit to **HTML** (not PDF) and that `plotly` is installed.
- If fonts or layout look plain, that's normal for ioslides; the grader only requires a presentation and a plotly widget.
