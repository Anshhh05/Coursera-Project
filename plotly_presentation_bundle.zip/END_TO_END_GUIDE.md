# End-to-End Guide (Everything Included)

Below is the full process. Any step you must do manually is flagged as:

>>> YOU DO THIS <<<

---

## 1) Files included
- `presentation.Rmd` — R Markdown **ioslides presentation** with date and **Plotly**.
- `render_publish.R` — one-click R script to install packages and render.
- `README_publish.md` — short publishing reference.
- `quick_checklist.md` — short checklist.
  
Optional (for GitHub Pages):
- `gh-pages_instructions.txt` — copy-paste setup steps for GitHub Pages.

---

## 2) Local render (first time)

>>> YOU DO THIS <<< Open RStudio (Desktop).

In the **Console**, run:
```r
source("render_publish.R")
```
This will install any missing packages and create `presentation.html` next to the Rmd.

Alternatively, open `presentation.Rmd` and click **Knit**.

Verify:
- The title slide shows today's **date**.
- Both Plotly charts are **interactive**.

---

## 3) Publish options (choose ONE)

### A) RPubs (fastest) — RStudio GUI
>>> YOU DO THIS <<<
1. With `presentation.html` open in the **Viewer** pane, click **Publish** → **RPubs**.
2. Fill in Title/Description → click **Publish**.
3. Copy the live **RPubs URL**.

### B) GitHub Pages (free, stable URL)
>>> YOU DO THIS <<<
1. Create a new GitHub repo (e.g., `plotly-presentation`).  
2. Upload `presentation.html` and rename it to **`index.html`** (so it serves as the homepage).  
3. Go to **Settings → Pages**. Under "Build and deployment":
   - Source: **Deploy from a branch**
   - Branch: `main` (or your default) and root folder `/`
4. Save — wait a minute. Your site appears at `https://<username>.github.io/plotly-presentation/`.
5. Open that URL to confirm the slideshow and interactivity.
(Details also in `gh-pages_instructions.txt`.)

### C) NeoCities (drag-and-drop upload)
>>> YOU DO THIS <<<
1. Create/login to **NeoCities**.  
2. Upload `presentation.html` (or rename to `index.html` for the homepage).  
3. Visit your live site URL and confirm the interactive charts.

---

## 4) Submit
>>> YOU DO THIS <<< Copy the live URL and submit it on Coursera.

**Rubric Mapping**
- Date within 2 months: Generated from `Sys.Date()` *at knit time*.
- Presentation + Plotly: `ioslides_presentation` with Plotly widgets embedded.

---

## Troubleshooting
- If the charts aren’t interactive, make sure you knit to **HTML** and not PDF.
- If RPubs publish button doesn’t show, open `presentation.html` in the Viewer first.  
- If GitHub Pages 404s, wait 2–3 minutes and refresh the URL.
