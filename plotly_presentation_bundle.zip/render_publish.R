# render_publish.R
# Installs required packages (if missing) and renders the R Markdown presentation.
pkgs <- c("rmarkdown", "plotly", "dplyr", "tibble")
to_install <- pkgs[!pkgs %in% rownames(installed.packages())]
if (length(to_install)) install.packages(to_install, repos = "https://cloud.r-project.org")

rmarkdown::render("presentation.Rmd")
cat("Rendered: presentation.html\n")
